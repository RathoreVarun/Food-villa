
const Instamart = () => {
    return (
        <h1>This is the component for instamart.</h1>
    );
}

export default Instamart;